package com.Polymorphism;

public class Main {

	public static void main(String[] args) {
   
		ComplileTimePolymorphism ctp = new ComplileTimePolymorphism();
		System.out.println(ctp.add(4, 8));
		System.out.println(ctp.add(4, 8,12));
		System.out.println(ctp.add(4.82, 8.31));
	}

}
