package InterfaceDemo;

public interface Fruits {
	
	 String color();
	

}
