package InterfaceDemo;

public class Apple implements Fruits{

	@Override
	public String color() {
		
		return "red";
	}

}
