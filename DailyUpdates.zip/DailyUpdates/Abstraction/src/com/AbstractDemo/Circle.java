package com.AbstractDemo;

public class Circle extends Shape{
	private double radius;
	
	

	public Circle(double radius) {
		super();
		this.radius = radius;
	}



	@Override
	double calculateArea() {
		return Math.PI * Math.pow(radius,2);
	}

}
