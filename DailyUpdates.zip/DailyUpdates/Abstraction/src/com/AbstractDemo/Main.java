package com.AbstractDemo;

import InterfaceDemo.Apple;

public class Main {
	
	public static void main(String[]args) {
		
		Circle c = new Circle(5);
		Square s = new Square(4);
		Apple a = new Apple();
		
		c.message();
		System.out.println("Circle = " + c.calculateArea());
		
		Shape.message();
		System.out.println("Square = " + s.calculateArea());
		
		System.out.println("apple has " + a.color() + " in colour...");
		
		}
}
