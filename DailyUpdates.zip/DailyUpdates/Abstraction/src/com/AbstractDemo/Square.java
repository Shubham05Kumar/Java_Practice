package com.AbstractDemo;

public class Square extends Shape{
	
	private double side;
	

	public Square(double side) {
		super();
		this.side = side;
	}


	@Override
	double calculateArea() {
		
		return Math.pow(side, 2);
	}
   
	
}
