package com.AbstractDemo;

abstract class Shape {
	
	static void message() {
		System.out.println("calculating the area of ");
	}
	abstract double calculateArea();

	
}
