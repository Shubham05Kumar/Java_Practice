package com.JActionListener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class JActionListenerExample {

	JActionListenerExample(){
		JFrame f = new JFrame("Action Listener Example");
		
		JLabel l1 = new  JLabel("input 1 :");
		l1.setBounds(50, 50, 60, 30);
		JLabel l2 = new  JLabel("input 2 :");
		l2.setBounds(50, 100, 60, 30);
		JLabel l3 = new  JLabel("output  :");
		l3.setBounds(50, 150, 60, 30);
		
		JTextField tf1 = new JTextField("");
		tf1.setBounds(120, 50, 120, 30);
		JTextField tf2 = new JTextField("");
		tf2.setBounds(120, 100, 120, 30);
		JTextField tf3 = new JTextField("");
		tf3.setBounds(120, 150, 120, 30);
		tf3.setEditable(false);
		
		JButton b1 = new JButton("+");
		b1.setBounds(60, 200, 50, 20);
		JButton b2 = new JButton("-");
		b2.setBounds(120, 200, 50, 20);
		JButton b3 = new JButton("reset");
		b3.setBounds(180, 200, 70, 20);
		
		b1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String s1 = tf1.getText();
				String s2 = tf2.getText();
				  int a= Integer.parseInt(s1);  
			        int b= Integer.parseInt(s2);  
			        int c=0;  
			 if(e.getSource()==b1)  {
				 c = a+b;
			 }
			 String result=String.valueOf(c);  
		        tf3.setText(result); 
			}
			
		});
		b2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String s1 = tf1.getText();
				String s2 = tf2.getText();
				  int a= Integer.parseInt(s1);  
			        int b= Integer.parseInt(s2);  
			        int c=0;  
			 if(e.getSource()==b2)  {
				 c = a-b;
			 }
			 String result=String.valueOf(c);  
		        tf3.setText(result); 
			}
			
		});
		b3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				tf1.setText("");
				tf2.setText("");
				tf3.setText("");
			}
			
		});
		
		f.add(l1);
		f.add(l2);
		f.add(l3);
		f.add(tf1);
		f.add(tf2);
		f.add(tf3);
		f.add(b1);
		f.add(b2);
		f.add(b3);
		
		
		
		f.setLayout(null);
		f.setVisible(true);
		f.setSize(300, 300);
		
		
	}
	
	

	public static void main(String[] args) {

		new JActionListenerExample();
	}

	

	

}
