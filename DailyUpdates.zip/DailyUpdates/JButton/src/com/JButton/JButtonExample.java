package com.JButton;

import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class JButtonExample {
	
	JButtonExample(){
		JFrame f = new JFrame("button example");
		JLabel l1 = new  JLabel("input :");
		l1.setBounds(90, 80, 60, 30);
		JTextField tf = new JTextField(" before clicking the button");
		tf.setBounds(140, 80, 200, 30);
		JButton b = new JButton(new ImageIcon("C:\\Users\\SKUMAR67\\Downloads\\clickme.webp"));
		b.setBounds(180, 140, 90, 25);
		b.addActionListener( new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				tf.setText("after clicking the button");
			}
			
		});
		f.add(b);
		f.add(tf);
		f.add(l1);
		f.setSize(300, 300);
		f.setLayout(null);
		f.setVisible(true);
		f.setEnabled(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}

	public static void main(String[] args) {
		JButtonExample jButtonExample = new JButtonExample();

	}

}
