package com.Button;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Label;

public class ButtonExample {

	ButtonExample(){
		
		Frame f = new Frame("Button Example");
		
		 Label l = new  Label("this is Lebel");
		 l.setBounds(30, 60, 150, 50);
		 l.contains(30, 80);
		Button b = new Button("click me");
		b.setBounds(30, 100, 80, 30);
		b.setBackground(Color.white);
		
		f.add(b);
		f.add(l);
		f.setSize(300, 300);
		f.setLayout(null);
		f.setVisible(true);
		
	}
	public static void main(String[]args) {
		 ButtonExample  buttonExample = new  ButtonExample();
	}

}
;