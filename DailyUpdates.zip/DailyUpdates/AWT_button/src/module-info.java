/**
 * 
 */
/**
 * 
 */
module JavaAWT {
	requires java.desktop;
}