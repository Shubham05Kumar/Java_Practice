package com.ArrayList;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListExample {

	public static void main(String[] args) {
		
		ArrayList<String> arrList = new ArrayList();
		
		arrList.add("Shubham");
		arrList.add("Ayush");
		arrList.add("aditya");
		arrList.add("raj");
		arrList.add("shuryabhan");
		
		System.out.println(arrList);
		
		System.out.println("______________________________________");
		
		for(String names :arrList ) {
			System.out.println(names);
		}
		
		System.out.println("______________________________________");
		
		int count = 0;
		for(String names : arrList) {
			if(count<3) {
				System.out.println(names);
				count++;
			}
		}
		
		System.out.println("______________________________________");
		
		for(String names :arrList ) {
			if(names.startsWith("a")|| names.startsWith("A")) {
				System.out.println(names);
			}	
		}
		
		System.out.println("______________________________________");
		
		for(String names :arrList ) {
			if(names.contains("u")|| names.startsWith("ya")) {
				System.out.println(names);
			}
	}
		System.out.println("______________________________________iterator");
		
		Iterator<String> iterator = arrList.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}

}
}