package com.TextField;

import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextField;

public class TextFieldExample {
	
	TextFieldExample(){
		
		Frame f = new Frame();
		Label l = new  Label("Name");
		l.setBounds(50, 50, 50, 20);
		
		TextField t = new TextField();
		t.setBounds(110, 50, 150, 20);
		
		Button b = new Button("Submit");
		b.setBounds(140,80, 70, 20);
		
		
		f.add(l);
		f.add(t);
		f.add(b);
		
		f.setSize(300, 150);
		f.setLayout(null);
		f.setVisible(true);
		
		
	}

	public static void main(String[] args) {
		TextFieldExample textFieldExample = new TextFieldExample();
		
	}

}
