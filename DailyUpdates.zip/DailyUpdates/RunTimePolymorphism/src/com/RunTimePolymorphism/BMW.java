package com.RunTimePolymorphism;

public class BMW extends Car{
	
	void speed() {
		System.out.println("BMW has 100 Km/h speed");
	}

	@Override
	void color() {
		System.out.println("BMW has red color");
	}

}
