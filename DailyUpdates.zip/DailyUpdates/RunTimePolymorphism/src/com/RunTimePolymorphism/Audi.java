package com.RunTimePolymorphism;

public class Audi extends Car{

	@Override
	void color() {
		System.out.println("Audi has black color");
		
	}

}
