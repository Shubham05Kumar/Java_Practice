package com.RunTimePolymorphism;

 abstract class Car {
	 
	void speed() {
		System.out.println("car has no speed");
	}
  static void wheel() {
	  System.out.println("they have 4 wheel");
  }
  abstract void color();
}
