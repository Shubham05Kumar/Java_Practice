package com.RunTimePolymorphism;

public class Main {

	public static void main(String[] args) {
  
		BMW bmw = new BMW();
		Audi audi = new Audi();
		
		bmw.speed();
		bmw.wheel();
		bmw.color();
		System.out.println("__________________________________");
		audi.speed();
		audi.wheel();
		audi.color();
		
	}

}
