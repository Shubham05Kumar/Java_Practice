/**
 * 
 */
/**
 * 
 */
module JPanel {
	requires java.desktop;
}