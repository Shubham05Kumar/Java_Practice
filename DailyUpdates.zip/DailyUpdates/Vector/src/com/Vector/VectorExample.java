package com.Vector;

import java.util.Vector;

public class VectorExample {

	public static void main(String[] args) {
		
		Vector<Integer> v = new Vector<>();
		v.add(3);
		v.add(7);
		v.add(19);
		v.add(32);
		v.add(12);
		v.add(45);
		
		System.out.println(v);
		
		v.add(3, 27);
		
		System.out.println(v);
		
		System.out.println(v.capacity());
		
		v.add(14);
		v.add(2);
		v.add(10);
		v.add(64);
		
		System.out.println(v);
		System.out.println(v.capacity());
	}

}
