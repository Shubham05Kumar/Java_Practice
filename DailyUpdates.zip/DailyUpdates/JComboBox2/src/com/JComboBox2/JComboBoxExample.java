package com.JComboBox2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class JComboBoxExample extends JFrame implements ActionListener{

	JFrame f;
	JButton b;
	JLabel l;
	JComboBox cb;
	JComboBoxExample(){
		f = new JFrame("JComboBoxExample");
		
		l = new JLabel();
	    l.setHorizontalAlignment(JLabel.CENTER);  
	    l.setBounds(150,80,200,50);  
	    
		String country[] ={"India","Australia","Bangladesh","USA","China","Japan","Canada"};
		cb = new JComboBox(country);
		cb.setBounds(100, 150, 100, 20);
		
		b = new JButton("show");
		b.setBounds(230, 230, 70, 20);
		b.addActionListener(this);
		
		f.add(l);
		f.add(cb);
		f.add(b);
		
		 f.setLayout(null);    
		    f.setSize(350,350);    
		    f.setVisible(true);  
		    f.setCursor(getCursor());
		
	}
	
	
	public static void main(String[] args) {
 
		new JComboBoxExample();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		String data = "Country selected :" + cb.getItemAt(cb.getSelectedIndex());
		l.setText(data);
		
	}

}
