/**
 * 
 */
/**
 * 
 */
module JComboBox2 {
	requires java.desktop;
}