package com.LinkedHashSet;

import java.util.LinkedHashSet;

public class LinkedHashSetExample {

	public static void main(String[] args) {
    
		LinkedHashSet<String> LHS = new LinkedHashSet<>();
		LHS.add("neha");
		LHS.add("Aanya");
		LHS.add("shubham");
		LHS.add("ayush");
		LHS.add("raj");
		
		
		System.out.println(LHS);
		
	}

}
