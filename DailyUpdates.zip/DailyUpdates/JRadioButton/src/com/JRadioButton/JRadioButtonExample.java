package com.JRadioButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

public class JRadioButtonExample {

	JRadioButtonExample(){
		JFrame f = new JFrame();
		 JLabel l = new  JLabel("(Q).  how many days in month Of june?");
		 l.setBounds(100, 100, 280, 50);
		 
		 JRadioButton rb1 = new JRadioButton(" (A)     29");
		 rb1.setBounds(100, 150, 100, 30);
		 JRadioButton rb2 = new JRadioButton(" (B)     28");
		 rb2.setBounds(100, 180, 100, 30);
		 JRadioButton rb3 = new JRadioButton(" (C)     30");
		 rb3.setBounds(100, 210, 100, 30);
		 JRadioButton rb4 = new JRadioButton(" (D)     31");
		 rb4.setBounds(100, 240, 100, 30);
		 
		 JButton b= new JButton("submit");
		 b.setBounds(150, 300, 80, 30);
		 
		 ButtonGroup bg = new ButtonGroup();
		 bg.add(rb1);
		 bg.add(rb2);
		 bg.add(rb3);
		 bg.add(rb4);
		 
		 b.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(rb1.isSelected()) {
					JOptionPane.showMessageDialog(b,"wrong answer..");
				}
				else if(rb2.isSelected()) {
					JOptionPane.showMessageDialog(b,"wrong answer..");
				}
				else if(rb3.isSelected()) {
					JOptionPane.showMessageDialog(b," correct answer..");
				}
				else if(rb4.isSelected()) {
					JOptionPane.showMessageDialog(b,"wrong answer..");
				}
				else {
					JOptionPane.showMessageDialog(b,"choose any one option");
				}
			}
			 
		 });
		 
		 
		 f.add(l);
		 f.add(rb1);
		 f.add(rb2);
		 f.add(rb3);
		 f.add(rb4);
		 f.add(b);
		 
		 f.setSize(300, 300);
		 f.setLayout(null);
		 f.setVisible(true);
	}
	
	public static void main(String[] args) {
     
		new  JRadioButtonExample();
		
	}

}
