/**
 * 
 */
/**
 * 
 */
module JRadioButton {
	requires java.desktop;
}