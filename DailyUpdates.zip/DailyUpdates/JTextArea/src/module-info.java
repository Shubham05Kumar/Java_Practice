/**
 * 
 */
/**
 * 
 */
module JTextArea {
	requires java.desktop;
}