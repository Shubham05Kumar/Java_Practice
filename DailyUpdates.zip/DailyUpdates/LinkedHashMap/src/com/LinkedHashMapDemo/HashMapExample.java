package com.LinkedHashMapDemo;

import java.util.LinkedHashMap;
import java.util.Map;

public class HashMapExample {

	public static void main(String[] args) {
      
		LinkedHashMap <Integer , String> LHM = new LinkedHashMap<>();
		
		LHM.put(1, "Shubham kumar");
		LHM.put(2, "ayush gupta");
		LHM.put(3, "aditya malviya");
		LHM.put(4, "shivam singh");
		
		
		   System.out.println(LHM);
        
	       System.out.println(LHM.containsKey(8));
		
	       System.out.println(LHM.remove(1));
	       System.out.println(LHM);
		
		
	}

}
