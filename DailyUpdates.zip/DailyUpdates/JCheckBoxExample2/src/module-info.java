/**
 * 
 */
/**
 * 
 */
module JCheckBoxExample2 {
	requires java.desktop;
}