package com.JCheckBoxExample2;



import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class JCheckBoxExample extends JFrame implements ActionListener {
	 JLabel l;
	 JCheckBox box1;
	 JCheckBox box2;
	 JCheckBox box3;
	 JCheckBox box4;
	 JButton b;
	JCheckBoxExample(){
		JFrame f = new JFrame("JCheckBox example 2");
		
		
		 l =  new  JLabel("menu list");
		 l.setBounds(50, 50, 300, 20);
		
		 
		  box1 = new JCheckBox("lemon Tea @ 20");
		 box1.setBounds(100, 100, 150, 20);
		  box2 = new JCheckBox("Green Tea @ 40 ");
		 box2.setBounds(100, 150, 150, 20);
		  box3 = new JCheckBox("Black Tea @ 15 ");
		 box3.setBounds(100, 200, 150, 20);
		  box4 = new JCheckBox("masala Tea @ 30 ");
		 box4.setBounds(100, 250, 150, 20);
		 
		  b =  new JButton("order now");
		 b.setBounds(100, 300, 150, 20);
		
		 
		 b.addActionListener(this);
		 
		 
		 f.add(l);
		 f.add(box1);
		 f.add(box2);
		 f.add(box3);
		 f.add(box4);
		 f.add(b);
		 
		 f.setLayout(null);
		 f.setSize(400, 400);
		 f.setVisible(true);
		 
		 
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
 
			float amount = 0;
			String msg = "";
			if(box1.isSelected()) {
				amount += 20;
				msg += "Lemon Tea : Rs. 20\n";
			}
			if(box2.isSelected()) {
				amount += 40;
				msg += "Green Tea : Rs. 40\n";
			}
			if(box3.isSelected()) {
				amount += 15;
				msg += "black Tea : Rs. 15\n";
				
			}
			if(box4.isSelected()) {
				amount += 30;
				msg += "Masala Tea : Rs. 30\n";
			}
			  msg+="----------------------------\n";  
		        JOptionPane.showMessageDialog(this,msg+"Total: Rs. "+amount);   
		}
	


	public static void main(String[] args) {
		 SwingUtilities.invokeLater(() -> new JCheckBoxExample());
	}


	

	

}
