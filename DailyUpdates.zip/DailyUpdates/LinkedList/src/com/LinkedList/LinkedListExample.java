package com.LinkedList;

import java.util.LinkedList;

public class LinkedListExample {

	public static void main(String[] args) {
		
		 LinkedList<String> Ll = new LinkedList<>();
	        Ll.add("Shyam");
	        Ll.add("ASHUTOSH");
	        Ll.add("mOHAN");
	        Ll.add("prince");
	        Ll.add("Rohit");
	        Ll.add("aanya");
	       
	        
	        System.out.println(Ll);
	        
	        Ll.addFirst("jayesh");
	        Ll.addLast("adit");
	        
	        System.out.println(Ll.size());
	        System.out.println(Ll);
	        
	       System.out.println(Ll.getFirst());
	       System.out.println(Ll.getLast());
	       System.out.println(Ll.indexOf("Rohit"));
	       
	       Ll.remove(1);
	       System.out.println(Ll);
	       
	       System.out.println(Ll.pop());
	       System.out.println(Ll);
	       
	       System.out.println(Ll.peek());
	       System.out.println(Ll.poll());
	       System.out.println(Ll.size());
	      
	}
}
