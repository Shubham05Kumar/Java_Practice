package com.TreeSet;

import java.util.TreeSet;

public class TreeSetExample {

	public static void main(String[] args) {
		
		TreeSet<String> ts = new TreeSet<>();
		
		 ts.add("red");
		 ts.add("yellow");
		 ts.add("green");
		 ts.add("black");
		 ts.add("white");
		 ts.add("blue");
		 ts.add("gray");
		 ts.add("voilet");
		 ts.add("marron");
		 ts.add("olivegreen");
		 ts.add("offwhite");
		 ts.add("darkred");
		 
		 System.out.println("name of colours :" + ts );
		 
		 System.out.println(ts.descendingSet());
		 
		 ts.forEach(color -> System.out.println(color));
		 
		 System.out.println("__________________________________________" );
		 
		 for(String color : ts) {
			 if(color.startsWith("o")||color.startsWith("b")) {
				 System.out.println(color);
			 }
		 }
		 

	}

}
