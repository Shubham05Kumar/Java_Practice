/**
 * 
 */
/**
 * 
 */
module JFlowLayout {
	requires java.desktop;
}