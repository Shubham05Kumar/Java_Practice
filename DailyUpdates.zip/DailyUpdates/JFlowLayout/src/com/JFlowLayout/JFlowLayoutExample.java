package com.JFlowLayout;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class JFlowLayoutExample {

	 JFlowLayoutExample(){
		 JFrame f = new JFrame();
		f.setSize(500, 500);
		 f.setLayout(new FlowLayout(FlowLayout.CENTER,10,10));
		 
		 JPanel panel = new JPanel();
		 panel.setPreferredSize(new Dimension(250,250));
		 panel.setBackground(Color.darkGray);
		 panel.setLayout(new FlowLayout());
		 
//		 JButton b1 = new JButton("1");
//		 JButton b2 = new JButton("2");
//		 JButton b3 = new JButton("3");
//		 JButton b4 = new JButton("4");
//		 JButton b5 = new JButton("5");
//		 JButton b6 = new JButton("6");
//		 JButton b7 = new JButton("7");
//		 JButton b8 = new JButton("8");
//		 JButton b9 = new JButton("9");
//		 JButton b10 = new JButton("10");
//		 
		
		
		 
		 panel.add(new JButton("1"));
		 panel.add(new JButton("2"));
		 panel.add(new JButton("3"));
		 panel.add(new JButton("4"));
		 panel.add(new JButton("5"));
		 
		 panel.add(new JButton("6"));
		 panel.add(new JButton("7"));
		 panel.add(new JButton("8"));
		 panel.add(new JButton("9"));
		 panel.add(new JButton("10"));
		
		
		
		
		
		 
		 f.add(panel);
		 f.setVisible(true);
		 
		 
		 
		 }
	
	public static void main(String[] args) {

		new  JFlowLayoutExample();
	}

}
