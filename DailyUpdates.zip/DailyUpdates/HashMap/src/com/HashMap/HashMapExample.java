package com.HashMap;

import java.util.HashMap;

public class HashMapExample {

	public static void main(String[] args) {

		HashMap<Integer, String> hm = new HashMap<>();
		
		hm.put(1, "Shubham");
		hm.put(2, "nehal");
		hm.put(3, "ankush");
		hm.put(4, "nikhil");
		hm.put(5, "anup");
		hm.put(6, "rahul");
		hm.put(7, "vijay");
		hm.put(8, "krishna");
		
		
		System.out.println(hm);
		System.out.println(hm.get(1));
		System.out.println(hm.getOrDefault(9,"pooja" ));
		
		
	}

}
