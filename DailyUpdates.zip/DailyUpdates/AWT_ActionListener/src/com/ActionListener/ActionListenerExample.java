package com.ActionListener;

import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionListenerExample {
	
	ActionListenerExample(){
		Frame f = new Frame();
		
		Label l1 = new  Label("Name");
		l1.setBounds(50, 50, 50, 20);
		
		Label l2 = new  Label("Email");
		l2.setBounds(50, 80, 50, 20);
		
		Label l3 = new  Label("Age");
		l3.setBounds(50, 110, 50, 20);
		
		TextField t1 = new TextField();
		t1.setBounds(110, 50, 150, 20);
		
		TextField t2 = new TextField();
		t2.setBounds(110, 80, 150, 20);
		
		TextField t3 = new TextField();
		t3.setBounds(110, 110, 150, 20);
		
		
		Button b = new Button("Submit");
		b.setBounds(120, 140, 60, 30);
		
		Button b1 = new Button("reset");
		b1.setBounds(200, 140, 60, 30);
		
		
		b.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
              String name = t1.getText();
              String email = t2.getText();
              String age = t3.getText();
              
              System.out.println("Name : " + name );
              System.out.println("Email : " + email );
              System.out.println("Age : " + age );
			}
			
		});
		

		b1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
              t1.setText(" ");
              t2.setText(" ");
              t3.setText(" ");
              
             
			}
			
		});
		
		f.add(l1);
		f.add(l2);
		f.add(l3);
		f.add(t1);
		f.add(t2);
		f.add(t3);
		f.add(b);
		f.add(b1);
		f.setSize(300, 300);
		f.setLayout(null);
		f.setVisible(true);
		
	}

	public static void main(String[] args) {

		ActionListenerExample actionListenerExample = new ActionListenerExample();
	}

}
