/**
 * 
 */
/**
 * 
 */
module AWT_ActionListener {
	requires java.desktop;
}