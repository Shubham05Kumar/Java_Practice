/**
 * 
 */
/**
 * 
 */
module AWT_TextArea {
	requires java.desktop;
}