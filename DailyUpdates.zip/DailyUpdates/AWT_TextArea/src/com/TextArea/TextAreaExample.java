package com.TextArea;

import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextArea;

public class TextAreaExample{
	
	TextAreaExample (){
		Frame f = new Frame();
		
		Label l = new  Label("Comments");
		l.setBounds(50, 50, 70, 20);
	   
		TextArea t = new TextArea();
		t.setBounds(120, 50, 200, 100);
		t.setEditable(true);
		t.setRows(5);
		t.setColumns(30);
		
		Button b = new Button("Submit");
		b.setBounds(150, 170, 80, 30);
		
		f.add(l);
		f.add(t);
		f.add(b);
		
		f.setSize(400,250);
		f.setLayout(null);
		f.setVisible(true);
	}
	
	

	public static void main(String[] args) {
		 TextAreaExample  textAreaExample = new  TextAreaExample();
		
	}

}
