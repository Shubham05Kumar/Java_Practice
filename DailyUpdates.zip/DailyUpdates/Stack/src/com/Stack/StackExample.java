package com.Stack;

import java.util.Stack;

public class StackExample {

	public static void main(String[] args) {
		
		Stack<String> stack = new Stack();
		stack.push("rahul");
		stack.push("ajay");
		stack.push("shivam");
		stack.push("PRASHANT");
		stack.push("Nehal");
		stack.push("sagar");
		
		System.out.println(stack);
		System.out.println(stack.capacity());
		
		stack.trimToSize();
		
		System.out.println(stack.capacity());
		stack.push("shubham");
		
		System.out.println(stack.capacity());
		
		
		Stack<String> st = new Stack<>();
		st.push("delhi");
		st.push("mumbai");
		st.push("bhopal");
		st.push("pune");
		st.addAll(stack);
		
		System.out.println(st);
		
		st.pop();
		System.out.println(st);
		
		stack.clear();
		System.out.println(stack);
		
		
		
		
		
	}

}
