package com.HashSet;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetExample {

	public static void main(String[] args) {

		HashSet<Integer> hs = new HashSet<>();
		 
		    hs.add(6);
		    hs.add(26);
		    hs.add(51);
		    hs.add(19);
		    hs.add(33);
		    hs.add(45);
		    hs.add(39);
		    hs.add(6);
		    
		    System.out.println(hs);
		    System.out.println(hs.size());
		    System.out.println("it is printing through for each method....");
		    for(int i: hs) {
		    	 System.out.println(i);
		    	 
		    }
		 System.out.println("it is printing through iteratot....");
		    Iterator<Integer> it = hs.iterator();
		    while(it.hasNext()) {
		    	System.out.println(it.next());
		    }
		    
		    hs.remove(6);
		    System.out.println(hs);
		    
		    System.out.println(hs.size());
		    
		    int count = 0;
		    for(int i: hs) {
		    	if(count<2 ) {
		    		 System.out.println(i);
				    	count++;
		    	}
		    }
		    
		    
	}

}
