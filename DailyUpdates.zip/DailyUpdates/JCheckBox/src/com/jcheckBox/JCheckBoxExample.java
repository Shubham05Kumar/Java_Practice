package com.jcheckBox;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class JCheckBoxExample {
	 
	JCheckBoxExample(){
		
		JFrame f = new JFrame("JCheckBox Example");
		
		    JLabel label = new JLabel();            
	        label.setHorizontalAlignment(JLabel.CENTER);    
	        label.setSize(400,100);    
	        JLabel label1 = new JLabel();            
	        label1.setHorizontalAlignment(JLabel.CENTER);    
	        label1.setSize(400,150);    
		 
		JCheckBox box1 = new JCheckBox("c++ ");
		box1.setBounds(100, 100, 60, 60);
		
		JCheckBox box2 = new JCheckBox("java");
		box2.setBounds(100, 150, 60, 60);
		
		box1.addItemListener(new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent e) {
			
				label.setText("c++ checkbox : " 
				  + (e.getStateChange()==1?"true":"false")
				
						);
			}
			
		});
		box2.addItemListener(new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent e) {
			
				label1.setText("java checkbox : " 
				  + (e.getStateChange()==1?"true":"false")
				
						);
			}
			
		});
		
		f.add(box1);
		f.add(box2);
		f.add(label);
		f.add(label1);
		f.setLayout(null);
		f.setSize(400, 400);
		f.setVisible(true);
		
		
	}
	

	public static void main(String[] args) {
		new JCheckBoxExample();

	}

}
