/**
 * 
 */
/**
 * 
 */
module JCheckBox {
	requires java.desktop;
}