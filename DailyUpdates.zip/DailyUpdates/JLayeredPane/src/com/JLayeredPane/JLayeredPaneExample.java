package com.JLayeredPane;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;

public class JLayeredPaneExample {
	 
	JLayeredPaneExample(){
		
		JFrame frame = new JFrame();
		
		
		JLabel l1 = new JLabel();
		l1.setOpaque(true);
		l1.setBounds(50, 50, 200, 200);
		l1.setBackground(Color.red);
		
		JLabel l2 = new JLabel();
		l2.setOpaque(true);
		l2.setBounds(100, 100, 200, 200);
		l2.setBackground(Color.yellow);
		
		JLabel l3 = new JLabel();
		l3.setOpaque(true);
		l3.setBounds(150, 150, 200, 200);
		l3.setBackground(Color.green);
		
		JLayeredPane lp =new JLayeredPane();
		lp.setBounds(0, 0, 500, 500);
		lp.setOpaque(true);
		lp.setForeground(Color.black);
		
		lp.add(l1, JLayeredPane.DEFAULT_LAYER);
		lp.add(l2,JLayeredPane.POPUP_LAYER);
		lp.add(l3,JLayeredPane.DRAG_LAYER);
		
		frame.add(lp);
		frame.setSize(new Dimension(500,500));
		frame.setLayout(null);
		frame.setVisible(true);
		
		
	}

	public static void main(String[] args) {

		new JLayeredPaneExample();
	}

}
