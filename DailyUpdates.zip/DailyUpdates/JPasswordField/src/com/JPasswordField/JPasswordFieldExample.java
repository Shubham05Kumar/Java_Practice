package com.JPasswordField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class JPasswordFieldExample {

	JPasswordFieldExample(){
		JFrame f = new JFrame("JPasswordExample");
		   
		final JLabel label = new JLabel();            
	     label.setBounds(20,150, 250,50); 
		
		JLabel l1 = new  JLabel("username :");
		l1.setBounds(20,20, 80,30);
		
		JLabel l2 = new  JLabel("password :");
		l2.setBounds(20,75, 80,30);
		
		JTextField tf = new JTextField();
		tf.setBounds(100,20, 100,30);
		
		JPasswordField pf = new JPasswordField();
		pf.setBounds(100,75,100,30);
		
		JButton b = new JButton("login");
		b.setBounds(100,120, 80,30);
		
		b.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				String d1 = "username: " + tf.getText();
				     d1 += ", password: " + new String(pf.getPassword());
				     label.setText(d1);
				}
			
		});
		
		
		f.add(l1);
		f.add(l2);
		f.add(tf);
		f.add(pf);
		f.add(b);
		f.add(label);
		
		  f.setSize(300,300);    
          f.setLayout(null);    
          f.setVisible(true); 
          
	}
	
	public static void main(String[] args) {
		
		new JPasswordFieldExample();

	}

}
