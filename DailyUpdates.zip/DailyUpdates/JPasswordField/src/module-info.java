/**
 * 
 */
/**
 * 
 */
module JPasswordField {
	requires java.desktop;
}