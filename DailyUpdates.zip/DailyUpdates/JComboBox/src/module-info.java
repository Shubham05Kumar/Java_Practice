/**
 * 
 */
/**
 * 
 */
module JComboBox {
	requires java.desktop;
}