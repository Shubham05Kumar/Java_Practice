package com.JComboBox;

import javax.swing.JComboBox;
import javax.swing.JFrame;

public class JComboBoxExample {
	
	JComboBoxExample(){
		JFrame f = new JFrame();
		String weekDays[]= {"Monday", "Tuesday", "Wednesday", "Thursday"," Friday", "Saturday", "Sunday"};
		JComboBox cb = new JComboBox(weekDays);
		cb.setBounds(100, 100, 100, 20);
		   f.add(cb);        
		    f.setLayout(null);    
		    f.setSize(400,500);    
		    f.setVisible(true);   
	}

	public static void main(String[] args) {

		new JComboBoxExample();
	}

}
